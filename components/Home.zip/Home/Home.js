import React from 'react';
import Link from 'next/link';
import Header from '../Header/Header';

export default function Home () {
    return(
        <React.Fragment>
            <Header />
            <div className='style--banner banner--style-1'>
                <div className='banner__wrapper'>
                    <div className='banner__content'>
                        <div className='banner__hgroup'>
                            <div className='banner__title'>
                                <h3>Invetorgate</h3>
                            </div>
                            <div className='banner__subtitle'>
                                <p>Expert insight, brought to light</p>
                            </div>
                        </div>
                        <div className='banner__text'>
                            <p>Uncover insights into the business models, competitive advantages and cultural attributes of the world’s leading companies. Directly from executives.</p>
                            <div className='banner__btn btn'>
                                <Link href="#">About us</Link>
                            </div>
                        </div>
                    </div>
                    <div className='banner__right--image'>
                        <img src="/images/ipad3.png" alt="Home banner" />
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}